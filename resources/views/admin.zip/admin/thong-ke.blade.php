


<div class="container mt-4">
    <h4>Thống kê tất cả món ăn theo ngày</h4>

    <form method="GET" action="{{ url('/thongke') }}" class="mb-3">
        <label for="ngay">Chọn ngày:</label>
        <input type="date" id="ngay" name="ngay" value="{{ $ngay }}">
        <button type="submit" class="btn btn-primary btn-sm">Xem</button>
    </form>

    @if ($monAn->isEmpty())
        <div class="alert alert-warning">Không có món nào được đặt trong ngày {{ \Carbon\Carbon::parse($ngay)->format('d/m/Y') }}.</div>
    @else
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Món ăn</th>
                    <th>Số lượng đã đặt</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($monAn as $item)
                    <tr>
                        <td>{{ $item->product_name }}</td>
                        <td>{{ $item->tong_so_luong }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif
</div>

